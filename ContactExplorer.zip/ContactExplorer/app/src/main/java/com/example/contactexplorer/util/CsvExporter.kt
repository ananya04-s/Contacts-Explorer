package com.example.contactexplorer.util

import android.content.Context
import android.os.Environment
import com.example.contactexplorer.model.ContactModel
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Exports the given list of contacts to a CSV file in the app's
 * external Documents directory and returns the resulting [File].
 */
object CsvExporter {

    @Throws(Exception::class)
    fun export(context: Context, contacts: List<ContactModel>): File {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "contacts_export_$timestamp.csv"

        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
            ?: context.filesDir
        if (!dir.exists()) dir.mkdirs()

        val file = File(dir, fileName)

        FileWriter(file).use { writer ->
            writer.append("Name,Phone Number\n")
            for (contact in contacts) {
                writer.append(escapeCsv(contact.name))
                writer.append(',')
                writer.append(escapeCsv(contact.phoneNumber))
                writer.append('\n')
            }
        }

        return file
    }

    /** Wraps a value in quotes and escapes inner quotes if it contains a comma, quote, or newline. */
    private fun escapeCsv(value: String): String {
        return if (value.contains(',') || value.contains('"') || value.contains('\n')) {
            "\"${value.replace("\"", "\"\"")}\""
        } else {
            value
        }
    }
}
