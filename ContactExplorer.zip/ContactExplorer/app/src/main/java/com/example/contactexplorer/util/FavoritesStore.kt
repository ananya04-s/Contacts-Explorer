package com.example.contactexplorer.util

import android.content.Context

/**
 * Lightweight local storage for "favorite" contact IDs using SharedPreferences.
 * Stored as a Set<String> of contact IDs.
 */
class FavoritesStore(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun isFavorite(contactId: String): Boolean {
        return getFavoriteIds().contains(contactId)
    }

    fun toggleFavorite(contactId: String): Boolean {
        val current = getFavoriteIds().toMutableSet()
        val nowFavorite: Boolean
        if (current.contains(contactId)) {
            current.remove(contactId)
            nowFavorite = false
        } else {
            current.add(contactId)
            nowFavorite = true
        }
        prefs.edit().putStringSet(KEY_FAVORITES, current).apply()
        return nowFavorite
    }

    fun getFavoriteIds(): Set<String> {
        return prefs.getStringSet(KEY_FAVORITES, emptySet()) ?: emptySet()
    }

    companion object {
        private const val PREFS_NAME = "contact_explorer_prefs"
        private const val KEY_FAVORITES = "favorite_contact_ids"
    }
}
