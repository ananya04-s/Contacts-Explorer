package com.example.contactexplorer.ui

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.contactexplorer.R
import com.example.contactexplorer.databinding.ActivityContactDetailBinding
import com.example.contactexplorer.model.ContactModel
import com.example.contactexplorer.util.FavoritesStore
import com.example.contactexplorer.util.PermissionUtils
import com.google.android.material.snackbar.Snackbar

/**
 * Shows full details for a single contact: large avatar, name, phone number,
 * a button to place a call, and a toggle for marking the contact as a
 * local favorite (stored via [FavoritesStore]).
 */
class ContactDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityContactDetailBinding
    private lateinit var favoritesStore: FavoritesStore
    private lateinit var contact: ContactModel

    private val requestCallPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                dialPhoneNumber(contact.phoneNumber)
            } else {
                Snackbar.make(binding.root, R.string.permission_denied_message, Snackbar.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityContactDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        favoritesStore = FavoritesStore(applicationContext)

        val id = intent.getStringExtra(EXTRA_CONTACT_ID).orEmpty()
        val name = intent.getStringExtra(EXTRA_CONTACT_NAME).orEmpty()
        val number = intent.getStringExtra(EXTRA_CONTACT_NUMBER).orEmpty()
        contact = ContactModel(id = id, name = name, phoneNumber = number)

        bindContact()
        setupListeners()
    }

    private fun bindContact() {
        binding.tvDetailName.text = contact.name
        binding.tvAvatarLarge.text = contact.initials()
        binding.tvDetailNumber.text = contact.phoneNumber.ifEmpty {
            getString(R.string.phone_number_label)
        }

        val colorRes = avatarColorFor(contact.name)
        val background = binding.tvAvatarLarge.background.mutate()
        if (background is GradientDrawable) {
            background.setColor(getColor(colorRes))
        }

        binding.btnCall.isEnabled = contact.phoneNumber.isNotEmpty()
        updateFavoriteIcon()
    }

    private fun setupListeners() {
        binding.btnBack.setOnClickListener { finish() }

        binding.btnCall.setOnClickListener {
            requestCallPermissionAndDial(contact.phoneNumber)
        }

        binding.btnFavorite.setOnClickListener {
            favoritesStore.toggleFavorite(contact.id)
            updateFavoriteIcon()
        }
    }

    private fun updateFavoriteIcon() {
        val isFavorite = favoritesStore.isFavorite(contact.id)
        binding.btnFavorite.setImageResource(
            if (isFavorite) R.drawable.ic_favorite else R.drawable.ic_favorite_border
        )
        binding.btnFavorite.contentDescription = getString(
            if (isFavorite) R.string.remove_from_favorites else R.string.add_to_favorites
        )
    }

    private fun requestCallPermissionAndDial(number: String) {
        if (number.isEmpty()) return
        if (PermissionUtils.hasCallPermission(this)) {
            dialPhoneNumber(number)
        } else {
            requestCallPermissionLauncher.launch(PermissionUtils.CALL_PHONE_PERMISSION)
        }
    }

    private fun dialPhoneNumber(number: String) {
        try {
            val intent = Intent(Intent.ACTION_CALL).apply { data = Uri.parse("tel:$number") }
            startActivity(intent)
        } catch (e: Exception) {
            val intent = Intent(Intent.ACTION_DIAL).apply { data = Uri.parse("tel:$number") }
            startActivity(intent)
        }
    }

    private fun avatarColorFor(name: String): Int {
        val colors = intArrayOf(
            R.color.avatar_bg_1,
            R.color.avatar_bg_2,
            R.color.avatar_bg_3,
            R.color.avatar_bg_4,
            R.color.avatar_bg_5,
            R.color.avatar_bg_6
        )
        return colors[Math.abs(name.hashCode()) % colors.size]
    }

    companion object {
        const val EXTRA_CONTACT_ID = "extra_contact_id"
        const val EXTRA_CONTACT_NAME = "extra_contact_name"
        const val EXTRA_CONTACT_NUMBER = "extra_contact_number"
    }
}
