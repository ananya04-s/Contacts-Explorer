package com.example.contactexplorer

import android.app.Application

/**
 * Application class for Contact Explorer.
 * Currently minimal, but provides a single place to initialize
 * app-wide dependencies if needed in the future.
 */
class ContactExplorerApp : Application()
