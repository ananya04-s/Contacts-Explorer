package com.example.contactexplorer.util

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.core.content.ContextCompat

/**
 * Small helper object that centralizes all READ_CONTACTS permission
 * related checks and intents, keeping Activities clean.
 */
object PermissionUtils {

    const val READ_CONTACTS_PERMISSION = Manifest.permission.READ_CONTACTS
    const val CALL_PHONE_PERMISSION = Manifest.permission.CALL_PHONE

    /** Returns true if READ_CONTACTS has already been granted. */
    fun hasContactsPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            READ_CONTACTS_PERMISSION
        ) == PackageManager.PERMISSION_GRANTED
    }

    /** Returns true if CALL_PHONE has already been granted. */
    fun hasCallPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            CALL_PHONE_PERMISSION
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Builds an Intent that opens this app's page in the system Settings app,
     * used when the permission has been permanently denied ("Don't ask again").
     */
    fun appSettingsIntent(context: Context): Intent {
        return Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }
}
