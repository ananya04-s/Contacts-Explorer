package com.example.contactexplorer.model

/**
 * Simple, immutable representation of a device contact.
 *
 * @param id Unique contact ID from ContactsContract (used for stable RecyclerView IDs and favorites)
 * @param name Display name of the contact
 * @param phoneNumber Primary phone number (may be empty if the contact has none)
 */
data class ContactModel(
    val id: String,
    val name: String,
    val phoneNumber: String
) {
    /**
     * Returns up to two initials derived from the contact's name,
     * used for the circular avatar (e.g. "John Doe" -> "JD").
     */
    fun initials(): String {
        if (name.isBlank()) return "#"
        val parts = name.trim().split(Regex("\\s+"))
        return when {
            parts.size >= 2 -> "${parts[0].first()}${parts[1].first()}".uppercase()
            else -> parts[0].take(1).uppercase()
        }
    }
}
