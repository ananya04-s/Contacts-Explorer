package com.example.contactexplorer.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.contactexplorer.R
import com.example.contactexplorer.adapter.ContactAdapter
import com.example.contactexplorer.databinding.ActivityMainBinding
import com.example.contactexplorer.model.ContactModel
import com.example.contactexplorer.repository.ContactRepository
import com.example.contactexplorer.util.CsvExporter
import com.example.contactexplorer.util.PermissionUtils
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Home screen of Contact Explorer.
 *
 * Responsibilities:
 *  - Requesting and handling the READ_CONTACTS runtime permission
 *  - Loading device contacts via [ContactRepository] on a background thread
 *  - Displaying contacts in a RecyclerView with search/filter support
 *  - Showing loading, empty, and error states
 *  - Supporting pull-to-refresh and CSV export
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var repository: ContactRepository
    private lateinit var adapter: ContactAdapter

    /** Full unfiltered list of contacts currently loaded. */
    private var allContacts: List<ContactModel> = emptyList()

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                loadContacts()
            } else {
                handlePermissionDenied()
            }
        }

    private val requestCallPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                pendingCallNumber?.let { dialPhoneNumber(it) }
            } else {
                Snackbar.make(binding.root, R.string.permission_denied_message, Snackbar.LENGTH_SHORT).show()
            }
            pendingCallNumber = null
        }

    /** Temporarily holds the number to call while waiting for CALL_PHONE permission result. */
    private var pendingCallNumber: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository = ContactRepository(applicationContext)

        setupRecyclerView()
        setupSearch()
        setupListeners()

        checkPermissionAndLoad()
    }

    // ----------------------------------------------------------------------------------
    // Setup
    // ----------------------------------------------------------------------------------

    private fun setupRecyclerView() {
        adapter = ContactAdapter(
            onContactClick = { contact ->
                val intent = Intent(this, ContactDetailActivity::class.java).apply {
                    putExtra(ContactDetailActivity.EXTRA_CONTACT_ID, contact.id)
                    putExtra(ContactDetailActivity.EXTRA_CONTACT_NAME, contact.name)
                    putExtra(ContactDetailActivity.EXTRA_CONTACT_NUMBER, contact.phoneNumber)
                }
                startActivity(intent)
            },
            onCallClick = { contact ->
                if (contact.phoneNumber.isNotEmpty()) {
                    requestCallPermissionAndDial(contact.phoneNumber)
                }
            }
        )

        binding.recyclerContacts.layoutManager = LinearLayoutManager(this)
        binding.recyclerContacts.adapter = adapter
        binding.recyclerContacts.setHasFixedSize(true)
    }

    private fun setupSearch() {
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val query = s?.toString().orEmpty()
                binding.btnClearSearch.visibility = if (query.isEmpty()) View.GONE else View.VISIBLE
                filterContacts(query)
            }

            override fun afterTextChanged(s: Editable?) {}
        })

        binding.btnClearSearch.setOnClickListener {
            binding.etSearch.setText("")
        }
    }

    private fun setupListeners() {
        binding.btnRefresh.setOnClickListener {
            checkPermissionAndLoad(showLoadingState = true)
        }

        binding.btnExport.setOnClickListener {
            exportContactsToCsv()
        }

        binding.swipeRefresh.setOnRefreshListener {
            checkPermissionAndLoad(showLoadingState = false)
        }
    }

    // ----------------------------------------------------------------------------------
    // Permission handling
    // ----------------------------------------------------------------------------------

    private fun checkPermissionAndLoad(showLoadingState: Boolean = true) {
        when {
            PermissionUtils.hasContactsPermission(this) -> {
                loadContacts(showLoadingState)
            }
            shouldShowRequestPermissionRationale(PermissionUtils.READ_CONTACTS_PERMISSION) -> {
                showPermissionRationaleDialog()
            }
            else -> {
                requestPermissionLauncher.launch(PermissionUtils.READ_CONTACTS_PERMISSION)
            }
        }
    }

    private fun showPermissionRationaleDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.permission_title)
            .setMessage(R.string.permission_message)
            .setCancelable(false)
            .setPositiveButton(R.string.permission_grant) { _, _ ->
                requestPermissionLauncher.launch(PermissionUtils.READ_CONTACTS_PERMISSION)
            }
            .setNegativeButton(R.string.cancel) { _, _ ->
                handlePermissionDenied()
            }
            .show()
    }

    private fun handlePermissionDenied() {
        showLoading(false)
        showEmptyState(true)

        val permanentlyDenied = !shouldShowRequestPermissionRationale(PermissionUtils.READ_CONTACTS_PERMISSION) &&
            !PermissionUtils.hasContactsPermission(this)

        if (permanentlyDenied) {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.permission_title)
                .setMessage(R.string.permission_permanently_denied_message)
                .setCancelable(true)
                .setPositiveButton(R.string.open_settings) { _, _ ->
                    startActivity(PermissionUtils.appSettingsIntent(this))
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        } else {
            Snackbar.make(binding.root, R.string.permission_denied_message, Snackbar.LENGTH_LONG)
                .setAction(R.string.retry) { checkPermissionAndLoad() }
                .show()
        }
    }

    /** Re-check permission whenever the user returns from Settings. */
    override fun onResume() {
        super.onResume()
        if (PermissionUtils.hasContactsPermission(this) && allContacts.isEmpty()) {
            loadContacts()
        }
    }

    // ----------------------------------------------------------------------------------
    // Loading contacts
    // ----------------------------------------------------------------------------------

    private fun loadContacts(showLoadingState: Boolean = true) {
        if (showLoadingState) showLoading(true)
        showEmptyState(false)

        lifecycleScope.launch {
            try {
                val contacts = withContext(Dispatchers.IO) {
                    repository.getContacts()
                }
                allContacts = contacts
                showLoading(false)
                binding.swipeRefresh.isRefreshing = false

                applyContacts(contacts, binding.etSearch.text?.toString().orEmpty())
            } catch (e: Exception) {
                showLoading(false)
                binding.swipeRefresh.isRefreshing = false
                showEmptyState(allContacts.isEmpty())

                Snackbar.make(binding.root, R.string.error_loading_contacts, Snackbar.LENGTH_LONG)
                    .setAction(R.string.retry) { checkPermissionAndLoad() }
                    .show()
            }
        }
    }

    private fun applyContacts(contacts: List<ContactModel>, query: String) {
        val filtered = if (query.isBlank()) {
            contacts
        } else {
            contacts.filter {
                it.name.contains(query, ignoreCase = true) ||
                    it.phoneNumber.contains(query, ignoreCase = true)
            }
        }

        adapter.submitList(filtered)
        binding.tvTotalCount.text = getString(R.string.total_contacts_format, contacts.size)

        val isEmpty = filtered.isEmpty()
        showEmptyState(isEmpty)

        if (isEmpty && query.isNotBlank()) {
            binding.tvEmptyTitle.text = getString(R.string.no_contacts_found)
        } else {
            binding.tvEmptyTitle.text = getString(R.string.empty_state_title)
        }
    }

    private fun filterContacts(query: String) {
        applyContacts(allContacts, query)
    }

    // ----------------------------------------------------------------------------------
    // UI state helpers
    // ----------------------------------------------------------------------------------

    private fun showLoading(loading: Boolean) {
        binding.loadingState.visibility = if (loading) View.VISIBLE else View.GONE
        binding.swipeRefresh.visibility = if (loading) View.GONE else View.VISIBLE
    }

    private fun showEmptyState(empty: Boolean) {
        binding.emptyState.visibility = if (empty) View.VISIBLE else View.GONE
        binding.swipeRefresh.visibility = if (empty) View.GONE else View.VISIBLE
    }

    // ----------------------------------------------------------------------------------
    // Calling a contact
    // ----------------------------------------------------------------------------------

    private fun requestCallPermissionAndDial(number: String) {
        if (PermissionUtils.hasCallPermission(this)) {
            dialPhoneNumber(number)
        } else {
            pendingCallNumber = number
            requestCallPermissionLauncher.launch(PermissionUtils.CALL_PHONE_PERMISSION)
        }
    }

    private fun dialPhoneNumber(number: String) {
        try {
            val intent = Intent(Intent.ACTION_CALL).apply {
                data = Uri.parse("tel:$number")
            }
            startActivity(intent)
        } catch (e: Exception) {
            // Fall back to dialer if direct call isn't permitted/possible
            val intent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$number")
            }
            startActivity(intent)
        }
    }

    // ----------------------------------------------------------------------------------
    // CSV export (bonus feature)
    // ----------------------------------------------------------------------------------

    private fun exportContactsToCsv() {
        if (allContacts.isEmpty()) {
            Snackbar.make(binding.root, R.string.export_failure, Snackbar.LENGTH_SHORT).show()
            return
        }

        lifecycleScope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    CsvExporter.export(applicationContext, allContacts)
                }
                Snackbar.make(
                    binding.root,
                    getString(R.string.export_success, file.absolutePath),
                    Snackbar.LENGTH_LONG
                ).show()
            } catch (e: Exception) {
                Snackbar.make(binding.root, R.string.export_failure, Snackbar.LENGTH_LONG).show()
            }
        }
    }
}
