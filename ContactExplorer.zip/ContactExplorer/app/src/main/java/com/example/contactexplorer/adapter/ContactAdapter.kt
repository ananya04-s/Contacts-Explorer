package com.example.contactexplorer.adapter

import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.contactexplorer.R
import com.example.contactexplorer.databinding.ItemContactBinding
import com.example.contactexplorer.model.ContactModel

/**
 * RecyclerView adapter for displaying [ContactModel] items.
 *
 * Uses [ListAdapter] + [DiffUtil] for efficient, animated updates when the
 * underlying contact list changes (e.g. due to search filtering or refresh).
 */
class ContactAdapter(
    private val onContactClick: (ContactModel) -> Unit,
    private val onCallClick: (ContactModel) -> Unit
) : ListAdapter<ContactModel, ContactAdapter.ContactViewHolder>(DIFF_CALLBACK) {

    // A small palette of avatar background colors, cycled through by name hash
    private val avatarColors = intArrayOf(
        R.color.avatar_bg_1,
        R.color.avatar_bg_2,
        R.color.avatar_bg_3,
        R.color.avatar_bg_4,
        R.color.avatar_bg_5,
        R.color.avatar_bg_6
    )

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactViewHolder {
        val binding = ItemContactBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ContactViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ContactViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ContactViewHolder(private val binding: ItemContactBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(contact: ContactModel) {
            binding.tvName.text = contact.name
            binding.tvNumber.text = contact.phoneNumber.ifEmpty {
                binding.root.context.getString(R.string.phone_number_label)
            }
            binding.tvAvatar.text = contact.initials()

            // Tint the circular avatar background based on a hash of the name
            val colorRes = avatarColors[Math.abs(contact.name.hashCode()) % avatarColors.size]
            val color = binding.root.context.getColor(colorRes)
            val background = binding.tvAvatar.background.mutate()
            if (background is GradientDrawable) {
                background.setColor(color)
            }

            binding.root.setOnClickListener { onContactClick(contact) }
            binding.ivPhoneIcon.setOnClickListener { onCallClick(contact) }
            binding.ivPhoneIcon.visibility =
                if (contact.phoneNumber.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE
        }
    }

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ContactModel>() {
            override fun areItemsTheSame(oldItem: ContactModel, newItem: ContactModel): Boolean {
                return oldItem.id == newItem.id && oldItem.phoneNumber == newItem.phoneNumber
            }

            override fun areContentsTheSame(oldItem: ContactModel, newItem: ContactModel): Boolean {
                return oldItem == newItem
            }
        }
    }
}
