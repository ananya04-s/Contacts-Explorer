package com.example.contactexplorer.repository

import android.content.Context
import android.provider.ContactsContract
import com.example.contactexplorer.model.ContactModel

/**
 * Responsible for retrieving contacts from the device using the
 * [ContentResolver] and [ContactsContract] APIs.
 *
 * Kept separate from UI code so it can easily be reused or unit tested.
 */
class ContactRepository(private val context: Context) {

    /**
     * Loads all contacts that have at least a name, sorted alphabetically (A-Z),
     * with duplicate (id, number) entries removed.
     *
     * This performs a blocking ContentResolver query and MUST be called
     * from a background thread.
     *
     * @throws Exception if the underlying content provider query fails.
     */
    fun getContacts(): List<ContactModel> {
        val contacts = LinkedHashMap<String, ContactModel>()

        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )

        // Sort directly via the query for efficiency; we still sort again
        // afterwards in case the provider doesn't honor the sort order.
        val sortOrder = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"

        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection,
            null,
            null,
            sortOrder
        )

        cursor?.use {
            val idIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID)
            val nameIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)

            while (it.moveToNext()) {
                val id = if (idIndex >= 0) it.getString(idIndex) ?: continue else continue
                val name = if (nameIndex >= 0) it.getString(nameIndex)?.trim().orEmpty() else ""
                val rawNumber = if (numberIndex >= 0) it.getString(numberIndex)?.trim().orEmpty() else ""

                if (name.isEmpty()) continue // Skip contacts without a name

                val normalizedNumber = normalizePhoneNumber(rawNumber)

                // Avoid duplicate entries: same contact id is kept only once,
                // preferring the entry that actually has a phone number.
                val existing = contacts[id]
                if (existing == null) {
                    contacts[id] = ContactModel(id = id, name = name, phoneNumber = normalizedNumber)
                } else if (existing.phoneNumber.isEmpty() && normalizedNumber.isNotEmpty()) {
                    contacts[id] = existing.copy(phoneNumber = normalizedNumber)
                }
            }
        }

        return contacts.values
            .distinctBy { "${it.id}-${it.phoneNumber}" }
            .sortedBy { it.name.lowercase() }
    }

    /**
     * Removes excessive whitespace from phone numbers while preserving
     * the original digits/symbols (e.g. "+", "-").
     */
    private fun normalizePhoneNumber(number: String): String {
        return number.replace(Regex("\\s+"), " ").trim()
    }
}
