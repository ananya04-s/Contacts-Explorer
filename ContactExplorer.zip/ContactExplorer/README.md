# 📱 Contact Explorer

A modern, Material Design 3 Android application built in **Kotlin** that retrieves and displays the device's phone contacts after requesting runtime permission to access them.

---

## 🎯 Project Overview

Contact Explorer is a polished, portfolio-ready Android app that demonstrates real-world Android development practices: runtime permission handling, efficient `ContentResolver`/`ContactsContract` queries, RecyclerView with `DiffUtil`, ViewBinding, Material Design 3 theming, and graceful handling of loading, empty, and error states.

---

## ✨ Features

- **Splash Screen** – branded gradient splash with logo, app name, and a short loading animation before navigating to the home screen.
- **Runtime Permission Handling**
  - Requests `READ_CONTACTS` at runtime (Android 13+ compatible).
  - Friendly rationale dialog if permission is denied.
  - "Open App Settings" prompt if permission is permanently denied.
- **Home Screen**
  - Gradient app bar with soft blue → teal accents.
  - Live search bar (filters by name or phone number) with a clear button.
  - Refresh button and pull-to-refresh support.
  - Total contact count display.
- **Contact List**
  - RecyclerView with rounded (16dp) Material cards, soft shadows, and ripple click animation.
  - Circular avatar with auto-generated initials and a color derived from the contact's name.
  - Tap-to-call phone icon on every card.
  - Contacts sorted alphabetically (A–Z), deduplicated, and gracefully handle missing phone numbers.
- **Contact Detail Screen**
  - Large avatar, name, and phone number.
  - Call button (requests `CALL_PHONE` permission).
  - Favorite/unfavorite toggle, persisted locally via `SharedPreferences`.
- **Search**
  - Real-time filtering as you type.
  - "No contacts found" message when a search returns nothing.
- **Empty State** – friendly illustration and message when the device has no contacts.
- **Loading State** – Material `CircularProgressIndicator` while contacts are being fetched on a background thread (no UI freezing).
- **Error Handling** – Snackbar with a "Retry" action if loading contacts fails.
- **Bonus Enhancements**
  - Export all loaded contacts to a CSV file (stored in app-specific external Documents directory).
  - Light & Dark mode support via Material 3 theme resources.
  - Adaptive app icon.

---

## 🖼 Screenshots

> _Add screenshots of the Splash Screen, Home Screen (with contacts), Search in action, Empty State, and Contact Detail Screen here._

| Splash | Home | Detail |
|--------|------|--------|
| _screenshot_ | _screenshot_ | _screenshot_ |

---

## 🛠 Tech Stack

- **Language:** Kotlin
- **IDE:** Android Studio
- **UI:** XML Layouts, Material Design 3, ViewBinding
- **Lists:** RecyclerView + `ListAdapter`/`DiffUtil`
- **Data Source:** `ContentResolver` + `ContactsContract`
- **Concurrency:** Kotlin Coroutines (`lifecycleScope`, `Dispatchers.IO`)
- **Persistence:** `SharedPreferences` (favorites)
- **Min SDK:** 24 · **Target/Compile SDK:** 34

---

## 📂 Project Structure

```
app/src/main/java/com/example/contactexplorer/
├── ContactExplorerApp.kt          # Application class
├── ui/
│   ├── SplashActivity.kt          # Branded splash screen
│   ├── MainActivity.kt            # Home screen: list, search, states
│   └── ContactDetailActivity.kt   # Contact detail + favorite + call
├── adapter/
│   └── ContactAdapter.kt          # RecyclerView ListAdapter with DiffUtil
├── model/
│   └── ContactModel.kt            # Immutable contact data class
├── repository/
│   └── ContactRepository.kt       # ContentResolver / ContactsContract queries
└── util/
    ├── PermissionUtils.kt         # Permission check & settings intent helpers
    ├── FavoritesStore.kt          # Local favorites persistence
    └── CsvExporter.kt             # CSV export helper

app/src/main/res/
├── layout/                        # activity_splash, activity_main, activity_contact_detail, item_contact
├── drawable/                      # gradients, icons, illustrations
├── values/ & values-night/        # colors, strings, themes (light/dark)
└── xml/                           # backup & data extraction rules
```

---

## 🚀 Setup Instructions

1. **Clone or extract** this project into a folder.
2. Open the folder in **Android Studio** (Hedgehog / 2023.1.1 or newer recommended).
3. Let Gradle sync automatically (requires internet access to download dependencies the first time).
4. Connect a real Android device (recommended) or start an emulator running **Android 8.0 (API 24)** or higher.
5. Click **Run ▶** to build and launch the app.
6. On first launch, grant the **Contacts** permission when prompted to see your device contacts.

> 💡 Emulators may have few or no contacts by default — add a few test contacts via the emulator's Contacts app to fully exercise the UI, or simply test the empty state.

---

## 🔐 Permissions Used

| Permission | Purpose |
|------------|---------|
| `READ_CONTACTS` | Required to query and display the device's contact list. |
| `CALL_PHONE` | Requested only when the user taps the call icon/button, to place a direct call. If denied, the app falls back to opening the dialer instead. |

All permissions are requested **at runtime**, with clear in-app explanations and a path to App Settings if permanently denied.

---

## 🔮 Future Enhancements

- Contact grouping by alphabet with sticky headers.
- Edit/add new contacts via `ContactsContract` write operations.
- Sync favorites with device-native "starred" contacts.
- Import contacts from a CSV/vCard file.
- Unit and UI tests for repository and adapter logic.
- Jetpack Compose migration.

---

## 👤 Author

**Contact Explorer** — built as a portfolio/internship project demonstrating modern Android development with Kotlin, Material Design 3, and Android best practices.
